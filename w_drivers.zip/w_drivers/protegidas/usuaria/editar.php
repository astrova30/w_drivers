<?php
include ('../../conexion/conexion#2.php')
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamiento | W-DRIVERS</title>
    <link rel="stylesheet" href="../../estilos/CSS/editar.css">
    <link rel="icon" type="image/x-icon" href="http://localhost/w_drivers/imagenes/icono2 (1) (1).ico">
</head>
<body>
    <?php
        if(isset($_POST['enviar'])) {

            $id=$_POST['id'];
            $nombre=$_POST['nombre'];
            $direccion=$_POST['partida'];
            $destino=$_POST['destino'];
            $fecha=$_POST['fecha'];
            $hora=$_POST['hora'];

            $sql="update agenda set nombre='".$nombre."',partida='".$direccion."',destino='".$destino."',fecha='".$fecha."',hora='".$hora."'";
            $resultado=mysqli_query($connect,$sql);

            if($resultado) {
                echo "<script language='JavaScript'>
                            alert('Tu cita se actualizó correctamente');
                            location.assign('miscitas.php')</script>";
            } else {
                echo "<script language='JavaScript'>
                            alert('Tu cita NO se actualizó correctamente');
                            location.assign('miscitas.php')</script>";
            }

            mysqli_close($connect);

        } else { 
            $id=$_GET['id'];
            $sql="select * from agenda where id='".$id."'";
            $result=mysqli_query($connect,$sql);

            $fila=mysqli_fetch_assoc($result);
            $nombre=$fila['nombre'];
            $partida=$fila['partida'];
            $destino=$fila['destino'];
            $fecha=$fila['fecha'];
            $hora=$fila['hora'];

            mysqli_close($connect);
    ?>
    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="lobby_usuaria.php">INICIO</a></li>
                <li><a href="miscitas.php">MIS CITAS</a></li>
                <li><a href="agendar.php">AGENDAR</a></li>
                <li><a href="#">CERRAR SESIÓN</a></li>
            </ul>
        </nav>
    </div>


        <div class="agendar">
            <div class="formulario">
            <h6 id="confie">¡EDITA TU CITA!</h6><br>
            <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
                <p class="space" for="">Nombre de Usuaria</p>
                <input class="inp" type="text" name="nombre" placeholder="Escribe tu nombre de usuaria" value="<?php echo $nombre; ?>">
                <p class="space" for="">Partida</p>
                <input  class="inp" type="text" name="partida" placeholder="Direccion de tú ubicación" value="<?php echo $partida; ?>">
                <p class="space" for="">Destino</p>
                <input  class="inp" type="text" name="destino" placeholder="Direccion del destino" value="<?php echo $destino; ?>">
                <p class="space" for="">Fecha</p>
                <input  class="inp" type="date" name="fecha" value="<?php echo $fecha; ?>">
                <p class="space" for="">Hora</p>
                <input  class="inp" type="time" name="hora" value="<?php echo $hora; ?>"><br><br>
                <input class="ag" name="enviar" type="submit" value="ACTUALIZAR CITA">
                <input type="hidden" name="id" value="<?php echo $id; ?>">

                <button class="volver"><a class="porfa" href="miscitas.php">VOLVER</a></button>

            </form>
            </div>
            <?php
                }
            ?>

<script src="../../estilos/java/particles.min.js"></script>
    <script src="../../estilos/java/app.js"></script>




</body>   
</html>
</body>
</html>