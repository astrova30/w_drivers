<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript">
        function confirmar() {
            return confirm('¿Estas segura de que quieres eliminar esta cita?');
        }
    </script>
    <title>Mis citas | W-DRIVERS</title>
    <link rel="stylesheet" href="../../estilos/CSS/miscitas.css">
    <link rel="icon" type="image/x-icon" href="http://localhost/w_drivers/imagenes/icono2 (1) (1).ico">
</head>
<body>

    <?php
        include("../../conexion/conexion#2.php");

        $sql="SELECT * FROM agenda";
        $resultado=mysqli_query($connect,$sql);
    ?>

    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="lobby_usuaria.php">INICIO</a></li>
                <li><a href="miscitas.php">MIS CITAS</a></li>
                <li><a href="agendar.php">AGENDAR</a></li>
                <li><a href="#">CERRAR SESIÓN</a></li>
            </ul>
        </nav>
    </div>

    <div class="citas">
        <div class="list">
            <p id="listas">Lista de Citas</p>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Partida</th>
                        <th>Destino</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        while($filas=mysqli_fetch_assoc($resultado)){
                    ?>
                    <tr>
                        <td><?php echo $filas['id'] ?></td>
                        <td><?php echo $filas['nombre'] ?></td>
                        <td><?php echo $filas['partida'] ?></td>
                        <td><?php echo $filas['destino'] ?></td>
                        <td><?php echo $filas['fecha'] ?></td>
                        <td><?php echo $filas['hora'] ?></td>
                        <td>
                            <?php echo "<a class='elimedit' href='editar.php?id=".$filas['id']."'>EDITAR</a>"; ?>
                            -
                            <?php echo "<a class='elimedit' href='eliminar.php?id=".$filas['id']."'onclick='return confirmar()'>ELIMINAR</a>"; ?>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
            <div class="rep"><a id="report" href="reportes.php">IMPRIMIR REPORTE</a></div>
            <?php
                mysqli_close($connect);
            ?>
        </div>
    </div>

<script src="../../estilos/java/particles.min.js"></script>
    <script src="../../estilos/java/app.js"></script>




</body>   
</html>
</body>
</html>