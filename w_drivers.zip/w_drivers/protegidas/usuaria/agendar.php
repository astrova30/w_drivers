
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamiento | W-DRIVERS</title>
    <link rel="stylesheet" href="../../estilos/CSS/agendar.css">
    <link rel="icon" type="image/x-icon" href="http://localhost/w_drivers/imagenes/icono2 (1) (1).ico">
</head>
<body>

    <?php
    include("../../conexion/conexion#2.php");

        if(isset($_POST['enviar'])) {
            $nombre=$_POST['nombre'];
            $direccion=$_POST['partida'];
            $destino=$_POST['destino'];
            $fecha=$_POST['fecha'];
            $hora=$_POST['hora'];

            $consulta="insert into agenda(nombre,partida,destino,fecha,hora) values ('".$nombre."','".$direccion."','".$destino."','".$fecha."','".$hora."')";

            $resul=mysqli_query($connect,$consulta);

            if($resul){
                echo "<script language='JavaScript'>
                        alert('Se ha programado el servicio!');
                        location.assign('miscitas.php');
                        </script>";
                
            }
        }
    ?>

    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="lobby_usuaria.php">INICIO</a></li>
                <li><a href="miscitas.php">MIS CITAS</a></li>
                <li><a href="agendar.php">AGENDAR</a></li>
                <li><a href="#">CERRAR SESIÓN</a></li>
            </ul>
        </nav>
    </div>

    <div class="citas">
        <div class="agendar">
            <div class="formulario">
            <h6 id="confie">¡AGENDA CON CONFIANZA!</h6><br>
            <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
                <p class="space" for="">Nombre de Usuaria</p>
                <input class="inp" type="text" name="nombre" placeholder="Escribe tu nombre de usuaria">
                <p class="space" for="">Partida</p>
                <input  class="inp" type="text" name="partida" placeholder="Direccion de tú ubicación">
                <p class="space" for="">Destino</p>
                <input  class="inp" type="text" name="destino" placeholder="Direccion del destino">
                <p class="space" for="">Fecha</p>
                <input  class="inp" type="date" name="fecha">
                <p class="space" for="">Hora</p>
                <input  class="inp" type="time" name="hora"><br><br>
                <input class="ag" name="enviar" type="submit" value="AGENDAR SERVICIO">

            </form>
            </div>
        </div>
        <div class="list">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d31815.035759200793!2d-74.14306924999998!3d4.61558075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2sco!4v1698013898901!5m2!1ses-419!2sco" width="716" height="550" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
            <?php
                mysqli_close($connect);
            ?>
        </div>


<script src="../../estilos/java/particles.min.js"></script>
    <script src="../../estilos/java/app.js"></script>




</body>   
</html>
</body>
</html>