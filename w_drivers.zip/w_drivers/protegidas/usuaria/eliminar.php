<?php
    $id=$_GET['id'];
    include("../../conexion/conexion#2.php");


    $sql="delete from agenda where id='".$id."'";
    $resultado=mysqli_query($connect,$sql);

    if($resultado) {
        echo "<script language='JavaScript'>
        alert('La cita se eliminó correctamente');
        location.assign('miscitas.php')</script>";
    } else {
        echo "<script language='JavaScript'>
        alert('No se pudo eliminar la cita');
        location.assign('miscitas.php')</script>";
    }






?>