<?php
require('../../reporte/fpdf.php');

class PDF extends FPDF {
    function Header() {
        // Logo
        $this->Image('../../imagenes/pdf.jpg', 0, -10, 220);
        $this->Ln(10);
        $this->SetFont('Arial', 'B', 10);
    }

    function Footer() {
        $this->SetFillColor(20, 19, 20);
        $this->Rect(0, 270, 220, 30, 'F');
        $this->SetY(-20);
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor(255, 255, 255);
        $this->SetX(90);
        $this->Cell(30, 10, 'W-Drivers', 0, 0, 'C');
        $this->Ln();
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);

$pdf->SetY(70);
$pdf->SetX(45);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFillColor(79, 59, 120);
$pdf->Cell(17, 9, 'id', 0, 0, 'C', 1);
$pdf->Cell(17, 9, 'nombre', 0, 0, 'C', 1);
$pdf->Cell(30, 9, 'partida', 0, 0, 'C', 1);
$pdf->Cell(30, 9, 'destino', 0, 0, 'C', 1);
$pdf->Cell(20, 9, 'fecha', 0, 0, 'C', 1);
$pdf->Cell(20, 9, 'hora', 0, 1, 'C', 1);

    include('../../conexion/conexion#2.php');
    require('../../conexion/conexion#2.php');

    $consulta = "SELECT * FROM agenda";
    $resultado = mysqli_query($connect,$consulta);

    $pdf->SetTextColor(0,0,0);
    $pdf->SetFillColor(240,245,255);

    while($row = $resultado->fetch_assoc()){
        $pdf->SetX(45);
        $pdf->Cell(17,9, $row['id'], 0, 0, 'C',1);
        $pdf->Cell(17,9, $row['nombre'], 0, 0, 'C',1);
        $pdf->Cell(30,9, $row['partida'], 0, 0, 'C',1);
        $pdf->Cell(30,9, $row['destino'], 0, 0, 'C',1);
        $pdf->Cell(20,9, $row['fecha'], 0, 0, 'C',1);
        $pdf->Cell(20,9, $row['hora'], 0, 0, 'C',1);

    }

$pdf->Output();

?>