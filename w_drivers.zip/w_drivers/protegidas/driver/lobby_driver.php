<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio Driver | W-DRIVERS</title>
    <link rel="stylesheet" href="../../estilos/CSS/lobby_driver.css">
    <link rel="icon" type="image/x-icon" href="http://localhost/w_drivers/imagenes/icono2 (1) (1).ico">
</head>
<body>
    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="lobby_driver.php">INICIO</a></li>
                <li><a href="#">NOVEDADES</a></li>
                <li><a href="servicios.php">SERVICIOS</a></li>
                <li><a href="#">CERRAR SESIÓN</a></li>
                
            </ul>
        </nav>
        

    </div>
    <div class="content">
        <h1>BIENVENIDA DRIVER</h1>
</div>


<script src="../../estilos/java/particles.min.js"></script>
    <script src="../../estilos/java/app.js"></script>




</body>   
</html>
</body>
</html>