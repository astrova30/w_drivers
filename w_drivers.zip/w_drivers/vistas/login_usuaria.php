
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../estilos/CSS/login_usuaria.css">
    <link rel="icon" type="image/x-icon" href="../imagenes/icono2 (1) (1).ico">
    <title>inicio Sesión Usuaria | W-DRIVERS</title>
</head>
<body>
    
    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="../index_principal.php">INICIO</a></li>
                <li><a href="conduce.php">CONDUCE</a></li>
                <li><a href="registrate.php">REGISTRATE</a></li>
                <li><a href="mas_informacion.php">MÁS INFORMACIÓN</a></li>
                <li><a href="contactanos.php">CONTÁCTANOS</a></li>
            </ul>
        </nav>
        

    </div>
        <div class="cajagrande">

            <div class="info">
                <h2 id="wel">Bienvenida de nuevo</h2>

                <p>
                Nos complace tenerlo nuevamente por aquí querido usuario, para nosotros es muy importante ofrecerle el mejor servicio, bueno, agradable, bonito y económico. ¡¿Cómo estás?!<br>
                    Si no tienes una cuenta, regístrate ahora
                </p>

                <a href="registrate.php">Registrar Usuaria</a>

                <img src="../imagenes/flores.png" alt="Viaja con nosotras">
            </div>

            <form class="form" action="../controladores/controlador_loginUser.php" method="POST">
                <input type="hidden" name="action" value="login">

            <h3>Inicio Sesión Usuaria</h3>

            <p>Ya lo sabes, W-Drivers es tu amiga de confianza, todo lo que hacemos, lo hacemos por ti, ¡entra sin miedo y agenda tu cita!</p>

    <div class="inputs">

            <h4>Nombre de Usuario</h4>
                <input class="box" type="text" name="nombre" placeholder="Escribe tu nombre" required>
            <h4>Contraseña</h4>
                <input class="box" type="password" name="contraseña"  placeholder="Escribe tu contraseña" required> 
                
                <input type="submit" value="ENTRAR" name="login" class="sub">
    </div>

            </form>

        </div>


        

        <script src="../estilos/java/particles.min.js"></script>
    <script src="../estilos/java/app.js"></script>



</body>
</html>