<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../estilos/CSS/login_driver.css">
    <link rel="icon" type="image/x-icon" href="../imagenes/icono2 (1) (1).ico">
    <title>Inicia Sesion Driver | W-DRIVERS</title>
</head>
<body>
    
    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="../index_principal.php">INICIO</a></li>
                <li><a href="conduce.php">CONDUCE</a></li>
                <li><a href="registrate.php">REGISTRATE</a></li>
                <li><a href="mas_informacion.php">MÁS INFORMACIÓN</a></li>
                <li><a href="contactanos.php">CONTÁCTANOS</a></li>
            </ul>
        </nav>


    </div>
    <div class="cajagrande">

        
    <form class="form" action="#" method="POST">
    <h3>INICIO SESIÓN DRIVER</h3>
    <p>Gracias por trabajar con nosotras, eres una pieza fundamental en toda nuestra cuestión, te lo agradecemos!</p>
    <div class="inputs">
        <h4>Tu nombre Driver</h4>
        <input class="box" type="text" name="nombre" placeholder="Escribe tu nombre" required>
        <h4>Contraseña</h4>
        <input class="box" type="password" name="password" placeholder="Escribe tu contraseña" required> 
        <input type="submit" value="Entrar" class="sub" href="">
    </div>
</form>
        <div class="info">
            <h2 id="wel">¡Hola!</h2>

            <p>
            Recuerda que sin ti nada de esto sería posible, eres nuestra navegante, mantienes el rumbo al volante,
                ¡Muchas gracias! Si eres nueva en el equipo y quieres conducir, ingresa aquí:
            </p>

            <a href="conduce.php">Registrar Driver</a>

            <img src="../imagenes/ladriv.png" alt="Viaja con nosotras">
        </div>



    </div>

    
    <script src="../estilos/java/particles.min.js"></script>
    <script src="../estilos/java/app.js"></script>




</body>
</html>
