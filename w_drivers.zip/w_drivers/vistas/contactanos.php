<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contáctanos | W-DRIVERS</title>
    <link rel="stylesheet" href="../estilos/CSS/contactanos.css">
    <link rel="icon" type="image/x-icon" href="../imagenes/icono2 (1) (1).ico">
</head>
<body>
    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="../index_principal.php">INICIO</a></li>
                <li><a href="conduce.php">CONDUCE</a></li>
                <li><a href="registrate.php">REGISTRATE</a></li>
                <li><a href="mas_informacion.php">MÁS INFORMACIÓN</a></li>
                <li><a href="contactanos.php">CONTÁCTANOS</a></li>
            </ul>
        </nav>

        

    </div>

    <form class="FORMULARIO" action="https://formsubmit.co/ochoaperezandreso1@gmail.com" method="POST">

        

        <h4>Contáctanos</h4>
        <p>Nombre</p>
        <input type="text" class="inputs" name="nombre" placeholder="Escribe tu nombre" required>
        <p>Número de teléfono</p>
        <input type="text" class="inputs" name="telefono" placeholder="Escribe tu numero de teléfono" required>
        <p>Correo Electrónico</p>
        <input type="email" class="inputs" name="correo" placeholder="Escribe tu número de teléfono" required>
        <p>Mensaje</p>
            <textarea name="message" id="message" cols="30" rows="5" placeholder="Escribe tu mensaje aquí"></textarea>
            <input type="submit" class="bot" value="Enviar Mensaje">

            <input type="hidden" name="_next" value="http://localhost/w_drivers/vistas/contactanos.php">
            <input type="hidden" name="_captcha" value="false">

    </form>


    
    <script src="../estilos/java/particles.min.js"></script>
    <script src="../estilos/java/app.js"></script>



</body>   
</html>