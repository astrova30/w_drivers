
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Registrate | W-DRIVERS</title>
    <link rel="stylesheet" href="../estilos/CSS/registrarse.css">
    <link rel="icon" type="image/x-icon" href="../imagenes/icono2 (1) (1).ico">
</head>
<body>
    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="../index_principal.php">INICIO</a></li>
                <li><a href="conduce.php">CONDUCE</a></li>
                <li><a href="registrate.php">REGISTRATE</a></li>
                <li><a href="mas_informacion.php">MÁS INFORMACIÓN</a></li>
                <li><a href="contactanos.php">CONTÁCTANOS</a></li>
            </ul>
        </nav>

        

    </div>

    <div class="FORMULARIO">
    <form action="../controladores/controlador_loginUser.php" method="POST">
        <input type="hidden" name="action" value="register">
        <h4>¡Registrarme!</h4>
        <p>Nombre</p>
        <input type="text" class="inputs" name="nombre" placeholder="Escribe tu nombre" required>
        <p>Número de Teléfono</p>
        <input type="text" name="telefono" class="inputs" placeholder="Escribe tu número de teléfono" required>
        <p>Correo Electrónico</p>
        <input type="email" name="correo" class="inputs" placeholder="Escribe tú correo electrónico" required>
        <p>Contraseña</p>
        <input type="password" name="contraseña" class="inputs" placeholder="Escribe una contraseña" required>
        <div class="enlaces">
            <input type="checkbox" name="terminos" required>
            <label for="">Acepto los <a href="mas_informacion.php">términos y condiciones.</a></label>
        </div>
        <input type="submit" value="ENVIAR" name="register" class="bot">
    </form>
</div>


    <script src="../estilos/java/particles.min.js"></script>
    <script src="../estilos/java/app.js"></script>


</body>   
</html>
