<!DOCTYPE html>
<html lang="en">
<head>
    <title>Más Información | W-DRIVERS</title>
    <link rel="stylesheet" href="../estilos/CSS/mas_informacion.css">
    <link rel="icon" type="image/x-icon" href="../imagenes/icono2 (1) (1).ico">
</head>
<body>
    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="../imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>

        </div>
        
        <nav>
            <ul>
                <li><a href="../index_principal.php">INICIO</a></li>
                <li><a href="conduce.php">CONDUCE</a></li>
                <li><a href="registrate.php">REGISTRATE</a></li>
                <li><a href="mas_informacion.php">MÁS INFORMACIÓN</a></li>
                <li><a href="contactanos.php">CONTÁCTANOS</a></li>
            </ul>
        </nav>

        </div>
        <section class="quienes_somos">
        <div class="cajagrande">
            <h1 class="tit">¿Quiénes somos?</h1>
            <p class="parrafo">Un joven y pequeño equipo proveniente del colegio Nuevo Chile, en la localidad de Bosa, es planeador, promotor y ejecutor de la presente página web.
                Dos chicos impulsados por el deseo de aprender una nueva área, un área rica en imaginación, pero con los únicos requisitos de la paciencia y autodeterminación.
                Han sido instruídos por distintos profesores o docentes como Gabriel Pinilla y Amalia Castro en el ámbito de la programación. A una corta edad se han enfrascado con una problemática de la 
                sociedad actual, el acoso al género femenino en los medios de transporte web como lo son UBER o DIDI. Por ello, han propuesto la inciativa W-Drivers, un servicio
                de transporte orientado a solo el género femenino, para más información <mark  class="importante">continúa bajando y conoce nuestros términos y condiciones.</mark>

            </p>
        </div>
        <div class="caja1">
            <div>
                <img class="lozano" src="../imagenes/lozano.png" alt="">
                <p class="nombre "><strong>Valentina Lozano</strong></p>
                <p class="nombres" >Jóven estudiante con una amplia capacidad analítica, es alegre, impulsadora, emprededora y gran gimnasta. 
                    ¡Defensora de los derechos de la mujer!
                </p>
            </div>
            
        </div>
        <div class="caja2">
            <img class="ochoa" src="../imagenes/8a.png" alt="">
            <p class="nombre" ><strong>Andrés Ochoa</strong></p>
            <p class="nombres" >Jóven estudiante con una brillante mente, algo tímido, pero comprensivo y paciente, un promotor de los derechos femeninos. Pieza clave en cualquier
                iniciativa, planeador y entusiasta.
            </p>
        </div>
        </section>

        <section class="terminos">
            <div class="contenido">


            <p><strong>Términos y Condiciones de Uso</strong></p>

        </div>
        </section>


        


        <script src="../estilos/java/particles.min.js"></script>
        <script src="../estilos/java/app.js"></script>

</body>
</html>