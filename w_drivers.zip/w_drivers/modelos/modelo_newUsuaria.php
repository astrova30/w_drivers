<?php
//llama la clase conexión que conecta con la base de datos
require "../conexion/conexion.php";

    //Se crea el modelo de clase registroUsuaria
    class registroUsuaria {
        protected $id;
        protected $nombre;
        protected $telefono;
        protected $correo;
        protected $contraseña;

    //Se crea el método para insertar usuarias en la base de datos
    public function InsertarUsuaria(){
        $con = new Conexion();
        $sql = "INSERT INTO usuarias (nombre, telefono, correo, contraseña) VALUES (?,?,?,?)";

        $insertar = $con->con->prepare($sql);
        $insertar->bind_param("ssss", $this->nombre, $this->telefono, $this->correo, $this->contraseña);
        $insertar->execute();
    }

    protected function SearchUsuarioForName($nombre)
    {
        $con = new Conexion();
        $sql = "SELECT * FROM usuarias WHERE nombre=?";
        $stmt = $con->con->prepare($sql);
        $stmt->bind_param("s", $nombre);
        if (!$stmt->execute()) {
            echo "Error en la consulta: " . $stmt->error;
            return false;
        }
        $result = $stmt->get_result();
        $objetoconsulta = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        $con->con->close();
        return $objetoconsulta;
    }

    
}

?>





