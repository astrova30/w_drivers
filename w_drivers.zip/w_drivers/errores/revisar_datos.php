<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../estilos/CSS/error.css">
    <link rel="icon" type="image/x-icon" href="../imagenes/icono2 (1) (1).ico">
    <title>Datos Inválidos | W-DRIVERS</title>
</head>
<body>
    <div id="particles-js"></div>
        
        <div class="navbar">
            <div class="titular">
                <img class="casco" src="../imagenes/casco.png" alt="">
                <h1>W-DRIVERS</h1>

            </div>
            
            <nav>
                <ul>
                    <li><a href="..index_principal.php">INICIO</a></li>
                    <li><a href="../vistas/conduce.php">CONDUCE</a></li>
                    <li><a href="../vistas/registrate.php">REGISTRATE</a></li>
                    <li><a href="../vistas/mas_informacion.php">MÁS INFORMACIÓN</a></li>
                    <li><a href="../vistas/contactanos.php">CONTÁCTANOS</a></li>
                </ul>
            </nav>
</div>

            <div class="big">
                <div class="errores">
                    <div class="info">
                        <h6>Datos Inválidos</h6><br><br>
                        <p>La <strong>contraseña</strong> o <strong>nombre de usuaria</strong> no se encuentran en la base de datos , inténtalo de nuevo.</p><br>
                        <p>Verifica que los campos insertados en el logueo coincidan con tus datos de registro.</p><br>
                        <p>Por lo pronto, aún no podrás despegar.</p>
                        <img class="cohete" src="../imagenes/error.png" alt="">
                    </div>

                </div>
                <div class="botones">
                    <div class="small">
                        <h6>¡OJO!</h6><br><br>
                        <p>Si aún no te has registrado en W-Drivers, no adquirirás lo servicios, registrte ahora    <strong><a href="../vistas/registrate.php"> aquí</a></strong>, 
                        si ya tienes una cuenta, vuelve al login, quizá solo fue un simple error a la hora de escribir.<p><br>
                        <img src="../imagenes/flecharosa.png" alt=""><br><br>

                        <button class="tub"><a href="../vistas/login_usuaria.php">Regresar</a></button>

                    </div>
                </div>

            </div>
            

            <script src="../estilos/java/particles.min.js"></script>
    <script src="../estilos/java/app.js"></script>


</body>
</html>