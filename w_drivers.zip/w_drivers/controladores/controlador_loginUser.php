<?php

// Requiere hacer un llamado al controlador de la sesión y al modelo de la Usuaria
require "../modelos/modelo_newUsuaria.php";
require "sesion_usuaria.php";

//crea una clase LoginUsuaria con los atributos del modelo de Usuaria
class LoginUsuaria extends registroUsuaria {

    //Función de redirección al lobby de la usuaria
    public function redirectLobby(){
        header("location: ../protegidas/usuaria/lobby_usuaria.php");
        exit();
    }

    //Funcion de redirigir al login de usuaria
    public function LoginView() {
        require "../vistas/login_usuaria.php";
    }

    //Funcion de redirigir al registro usuaria
    public function InsertView() {
        require "../vistas/registrate.php";
    }

    //Funcion de activar el InsertarUsuaria proveniente del modelo usuaria
    public function SaveInfoForModel($nombre, $telefono, $correo, $contraseña){
        $this->nombre = $nombre;
        $this->telefono = $telefono;
        $this->correo = $correo;
        $this->contraseña = $contraseña;
        $this->InsertarUsuaria();
        header("Location: ../vistas/login_usuaria.php");
    exit();

        
    }

    public function VerifyLogin($nombre, $contraseña)
    {
        $infousuario = $this->SearchUsuarioForName($nombre); // Asegurar que el nombre se pase al método

        if ($infousuario) {
            $usuario = $infousuario[0]; // Asumiendo que se obtiene un solo usuario
            if(password_verify($contraseña, $usuario['contraseña'])) {
                $_SESSION['nombre'] = $usuario['nombre'];
                $_SESSION['telefono'] = $usuario['telefono'];
                $_SESSION['correo'] = $usuario['correo'];
                $this->redirectLobby();
            } else {
                $this->redirectError();
            }
        } else {
            $this->redirectError();
        }
    }

    public function redirectError()
    {
        header("Location: ../errores/revisar_datos.php");
        exit();
    }
    
}

    //Si se presiona el action = a "login" e instancia la clase LoginUsuaria,la cual contiene los métodos del modelo
    if (isset($_GET['action']) && $_GET['action'] == "login") {
        $instanciarControlador = new LoginUsuaria();
        $instanciarControlador->LoginView();
    }

    //Al presionarse el botón del formualrio de registro, se instancian los métodos y se realiza la función Interview
    if (isset($_GET['action']) && $_GET['action'] == "register") {
        $instanciarControlador = new LoginUsuaria();
        $instanciarControlador->InsertView();
    }

    //Al presionarse el botón del formulario de registro, se instancian los métodos y se envían los datos del mismo por medio del "$_POST", la contraseña se define 
    //en una variable para que llegue encriptada a la base de datos
    if (isset($_POST["action"]) && $_POST["action"] == "register") {
        $instanciarControlador = new LoginUsuaria();
        $password = password_hash($_POST['contraseña'], PASSWORD_BCRYPT);
        $instanciarControlador->SaveInfoForModel(
            $_POST["nombre"],
            $_POST["telefono"],
            $_POST["correo"],
            $password
        );
    }


    //Se instancian los métodos del controlador, se realiza una verificación de nombre y contraseña
    if(isset($_POST["action"]) && $_POST["action"]=='login'){
        $instanciarControlador = new LoginUsuaria();
        $instanciarControlador->VerifyLogin($_POST["nombre"], $_POST["contraseña"]);
}
?>
