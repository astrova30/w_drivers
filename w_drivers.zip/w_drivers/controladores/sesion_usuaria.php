
<?php

    class StarterController{

        public function __construct()
        {
            session_start();
        }

        public function redireccionar(){
            header("Location ../vistas/registrate.php?action='login'");
        }
    }

    // para las páginas protegidas:
    // require '../controladores/sesion_usuaria.php';
    // $is = new StarterController();
    // if(empty($_SESSION['nombre'])) {
    //   $is->redirect();
    //}

?>
