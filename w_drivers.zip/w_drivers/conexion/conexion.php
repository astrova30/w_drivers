<?php
class Conexion {
    public $Host;
    public $User;
    public $Pass;
    public $dbname;
    public $con;

    public function __construct()
    {
        $this->Host = "localhost";
        $this->User = "root";
        $this->Pass = "";
        $this->dbname = "w_drivers";
        $this->con = new mysqli($this->Host, $this->User, $this->Pass, $this->dbname);
        if ($this->con->connect_errno) {
            throw new Exception("Fallo la conexion: " . $this->con->connect_error);
        }
    }
}

?>
