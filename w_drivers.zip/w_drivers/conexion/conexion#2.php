<?php

$dbname="w_drivers";
$dbuser="root";
$dbhost="localhost";
$dbpass="";

$connect=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);



?>