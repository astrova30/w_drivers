

CREATE DATABASE w_drivers;


CREATE TABLE usuarias (
    ID INT(11)AUTO_INCREMENT,
    nombre VARCHAR(500) NOT NULL,
    telefono VARCHAR(500) NOT NULL,
    correo VARCHAR(500) NOT NULL,
    contraseña VARCHAR(500) NOT NULL,
    PRIMARY KEY(ID))



    CREATE TABLE agenda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    partida VARCHAR(255) NOT NULL,
    destino VARCHAR(255) NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL
);
