<!DOCTYPE html>
<html lang="es">
<head>
    <title>Inicio | W-DRIVERS</title>
    <link rel="stylesheet" href="estilos/CSS/index_principal.css">
    <link rel="icon" type="image/x-icon" href="imagenes/icono2 (1) (1).ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
</head>
<body>
    <div id="particles-js"></div>
    
    <div class="navbar">
        <div class="titular">
            <img class="casco" src="imagenes/casco.png" alt="">
            <h1>W-DRIVERS</h1>
        </div>
        
        <nav>
            <ul>
                <li><a href="index_principal.php">INICIO</a></li>
                <li><a href="vistas/conduce.php">CONDUCE</a></li>
                <li><a href="vistas/registrate.php">REGISTRATE</a></li>
                <li><a href="vistas/mas_informacion.php">MÁS INFORMACIÓN</a></li>
                <li><a href="vistas/contactanos.php">CONTÁCTANOS</a></li>
            </ul>
        </nav>
        

    </div>

    <div class="content">
        <h2>VIAJAR CON W-DRIVER ES VIAJAR SEGURA</h2>
        <p>W-Drivers es la opción más fiable para que llegues segura a tu destino.
        <br>Viaja con confianza, tu seguridad es nuestra prioridad.</br></p>

        <div>
            <a href="vistas/login_usuaria.php"><button type="button"><span></span>USUARIA</button></a>
            <a href="vistas/login_driver.php"><button type="button"><span></span>DRIVER</button></a>
        </div>

        
    </div>


    <script src="estilos/java/particles.min.js"></script>
    <script src="estilos/java/app.js"></script>



</body>   
</html>